//
//  saasquatch.h
//  saasquatch
//
//  Created by Brendan Crawford on 2016-03-03.
//  Copyright © 2016 Brendan Crawford. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for saasquatch.
FOUNDATION_EXPORT double saasquatchVersionNumber;

//! Project version string for saasquatch.
FOUNDATION_EXPORT const unsigned char saasquatchVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <saasquatch/PublicHeader.h>